game.resources = [

    /* Graphics.
     */

    // UI Texture
    { name: "UI_Assets",    type: "image",  src: "data/img/UI_Assets.png" },

    /* JSON Content.
     */
     // texturePacker Atlas
     { name: "UI_Assets",         type: "json",   src: "data/img/UI_Assets.json" },
];
