game.resources = [
    { name : "blue", src : "data/img/blue.png", type : "image" },
    { name : "smoke", src : "data/img/smoke.png", type : "image" },
    { name : "fireball", src : "data/img/fireball.png", type : "image" },
    { name : "explosion", src : "data/img/explosion.png", type : "image" },
    { name : "rain", src : "data/img/rain.png", type : "image" },
    { name : "grid", src : "data/img/grid.png", type : "image" }
];
