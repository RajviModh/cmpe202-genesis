/**
 * melonJS Game Engine v__VERSION__
 * http://www.melonjs.org
 * @license {@link http://www.opensource.org/licenses/mit-license.php|MIT}
 * @copyright (C) 2011 - 2017, Olivier Biot, Jason Oster, Aaron McLeod
 */
