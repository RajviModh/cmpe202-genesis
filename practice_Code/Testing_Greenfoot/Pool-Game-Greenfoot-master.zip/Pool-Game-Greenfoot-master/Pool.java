/**
 * Write a description of class Pool here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Pool  
{
   public abstract void doDisplay();
   public abstract void doRemove();
}
