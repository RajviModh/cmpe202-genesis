
public enum StickStates  
{
    REMOVE, DISPLAY
}
    


