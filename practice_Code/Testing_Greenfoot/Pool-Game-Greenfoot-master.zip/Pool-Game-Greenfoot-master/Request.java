import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Request here.
 * 
 * @tusharkarkera (your name) 
 * @version (a version number or a date)
 */
public class Request extends Actor
{
	private String description;

	public Request(String description)
	{
		this.description = description;
	}

	public String getDescription()
	{
		return description;
	}
}

