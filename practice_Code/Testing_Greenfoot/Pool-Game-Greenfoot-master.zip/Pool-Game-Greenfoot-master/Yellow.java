import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;

public class Yellow extends BallDecorator
{   
    
    public Yellow()
    {
    }

   

    public Color draw() 
    {
        return new Color(255, 255 ,0);
    }
    
    /*public void act() 
    {
        setExactLocation(getExactX() + moveX, getExactY() + moveY);
    }*/
    
    
}
